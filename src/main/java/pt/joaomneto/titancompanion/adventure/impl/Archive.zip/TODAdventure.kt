package pt.joaomneto.titancompanion.adventure.impl

class TODAdventure : TFODAdventure()

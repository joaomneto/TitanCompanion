package pt.joaomneto.titancompanion.adventure.impl

class COTSWAdventure : TFODAdventure()

package pt.joaomneto.titancompanion.adventure.impl

class DOTDAdventure : TFODAdventure()

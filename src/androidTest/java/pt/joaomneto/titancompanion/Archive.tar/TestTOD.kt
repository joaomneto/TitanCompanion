package pt.joaomneto.titancompanion

import android.support.test.filters.LargeTest
import android.support.test.runner.AndroidJUnit4
import org.junit.runner.RunWith
import pt.joaomneto.titancompanion.consts.FightingFantasyGamebook.TALISMAN_OF_DEATH

@LargeTest
@RunWith(AndroidJUnit4::class)
class TestTOD : TestTWOFM() {

    override val gamebook = TALISMAN_OF_DEATH
}

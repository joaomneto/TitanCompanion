package pt.joaomneto.titancompanion.phase3

import android.support.test.filters.LargeTest
import android.support.test.runner.AndroidJUnit4
import org.junit.runner.RunWith
import pt.joaomneto.titancompanion.consts.FightingFantasyGamebook.SLAVES_OF_THE_ABYSS
import pt.joaomneto.titancompanion.TestST

@LargeTest
@RunWith(AndroidJUnit4::class)
class TestSOTA : TestST() {

    override val gamebook = SLAVES_OF_THE_ABYSS
}
